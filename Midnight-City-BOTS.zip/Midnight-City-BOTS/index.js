// Discord.js v14 + Axios
const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle, 
} = require("discord.js");
const axios = require("axios");

// ---------------- CONFIG ----------------
const BOT_TOKEN = "MTQwMTU4Mjc3NDk0MjQzNzQ0Nw.GfAehI.ZStB6-Y-6JrNLixIx3-YUbfwpxX1iyArsduZWA";
const CHANNEL_ID = "1389829270108508342"; // Discord channel for embed
const UNIVERSE_ID = "8518264877"; // Roblox Universe ID
const MAX_PLAYERS = 50; // Max players in Roblox
const RESTART_INTERVAL_HOURS = 5; // Server auto-restarts every 12 hours
// -----------------------------------------

const statusConfig = {
    onlineString: "🟢 Online",
    onlineColor: "#0BA70B",
    offlineString: "🔴 Offline",
    offlineColor: "#A70B28",
    buttons: [
        {
            label: "Connect",
            url: "https://www.roblox.com/games/123680365232281/Midnight-City",
            emoji: "1062338355909640233"
        },
        {
            label: "Discord",
            url: "https://discord.gg/g6ThjksWWZ",
            emoji: "1062338355909640233"
        }
    ]
};

// Create Discord client
const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

// ---------------- HELPERS ----------------
function formatTimeHM(ms) {
    const totalMinutes = Math.floor(ms / 1000 / 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours} hrs, ${minutes} mins`;
}

function getNextRestartHM(uptimeMs) {
    const totalMinutes = Math.floor(uptimeMs / 1000 / 60);
    const hoursUp = Math.floor(totalMinutes / 60);
    const minutesUp = totalMinutes % 60;

    let nextRestartHours = RESTART_INTERVAL_HOURS - hoursUp - 1;
    let nextRestartMinutes = 60 - minutesUp;

    if (nextRestartMinutes === 60) {
        nextRestartMinutes = 0;
        nextRestartHours += 1;
    }

    if (nextRestartHours < 0) nextRestartHours = 0;

    return `in ${nextRestartHours} hrs, ${nextRestartMinutes} mins`;
}

async function getRobloxStatus() {
    try {
        const res = await axios.get(
            `https://games.roblox.com/v1/games?universeIds=${UNIVERSE_ID}`,
        );
        if (!res.data?.data?.length)
            return { players: 0, maxPlayers: 0, status: "offline" };

        const game = res.data.data[0];
        const isPrivate = game.privacyType === "Private";

        if (isPrivate) {
            return {
                players: 0,
                maxPlayers: game.maxPlayers,
                status: "offline",
            };
        }

        return {
            players: game.playing ?? 0,
            maxPlayers: game.maxPlayers ?? 0,
            status: "online",
        };
    } catch (err) {
        console.error("Error fetching Roblox data:", err.message);
        return { players: 0, maxPlayers: 0, status: "offline" };
    }
}

// ---------------- BOT FUNCTIONS ----------------
async function sendStatusEmbed() {
    const channel = client.channels.cache.get(CHANNEL_ID);
    if (!channel) return console.error("Channel not found");

    const robloxData = await getRobloxStatus();
    const uptime = formatTimeHM(client.uptime);
    const nextRestart = getNextRestartHM(client.uptime);

    const timeNow = new Intl.DateTimeFormat("en-PH", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true, 
        timeZone: "Asia/Manila",
    }).format(new Date());

    // Update bot presence (Watching players)
    client.user.setPresence({
        activities: [
        ],
        status: "invisible",
    });

    const embed = new EmbedBuilder()
        .setTitle("Midnight City")
        .setURL(`https://www.roblox.com/games/${UNIVERSE_ID}/Midnight-City`)
        .setDescription(" ")
        .addFields(
            {
                name: "> STATUS",
                value: `\`\`\`${robloxData.status === "online" ? statusConfig.onlineString : statusConfig.offlineString}\`\`\``,
                inline: true,
            },
            {
                name: "> PLAYERS",
                value: `\`\`\`${Math.min(robloxData.players, MAX_PLAYERS)}/${MAX_PLAYERS}\`\`\``,
                inline: true,
            },
            {
                name: "> MNC",
                value: "```\nconnect midnightcity.roblox.ph          \n```",
            },
            {
                name: "> NEXT RESTART",
                value: `\`\`\`\n${nextRestart}\n\`\`\``,
                inline: true,
            },
            {
                name: "> UPTIME",
                value: `\`\`\`\n${uptime}\n\`\`\``,
                inline: true,
            },
        )
        .setThumbnail(
            "https://cdn.discordapp.com/attachments/1390575801187172452/1391623858024480768/cyr.png",
        )
        .setColor(
            robloxData.status === "online"
                ? statusConfig.onlineColor
                : statusConfig.offlineColor,
        )
        .setFooter({
            text: `txAdmin 8.0.1 • Updated every minute • Today at ${timeNow}`,
            iconURL: "https://imgur.com/KVkD2zo.png", 
        });

    // Buttons row with 2 buttons
    const row = new ActionRowBuilder().addComponents(
        statusConfig.buttons.map(
            (btn) =>
                new ButtonBuilder()
                    .setLabel(btn.label)
                    .setStyle(ButtonStyle.Link)
                    .setURL(btn.url)
                    .setEmoji(btn.emoji)
        )
    );

    // Edit last bot message if exists
    const messages = await channel.messages.fetch({ limit: 10 });
    const botMessage = messages.find((m) => m.author.id === client.user.id);

    if (botMessage) {
        await botMessage.edit({ embeds: [embed], components: [row] });
    } else {
        await channel.send({ embeds: [embed], components: [row] });
    }

    console.log(
        `Embed updated: [${Math.min(robloxData.players, MAX_PLAYERS)}/${MAX_PLAYERS}] - Status: ${robloxData.status}`,
    );
}

// ---------------- READY ----------------
client.once("ready", () => {
    console.log(`Logged in as ${client.user.tag}`);
    sendStatusEmbed();
    setInterval(sendStatusEmbed, 60000); // every 1 minute
});

// Login
client.login(BOT_TOKEN);