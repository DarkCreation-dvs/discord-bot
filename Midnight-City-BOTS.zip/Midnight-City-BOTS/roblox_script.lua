
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

-- Replace with your actual Repl URL
local BOT_URL = "https://your-repl-name.your-username.replit.dev"

local function updatePlayerCount()
    local playerCount = #Players:GetPlayers()
    local url = BOT_URL .. "/update/" .. playerCount
    
    -- Send request to update bot
    spawn(function()
        pcall(function()
            HttpService:GetAsync(url)
            print("Updated bot player count:", playerCount)
        end)
    end)
end

-- Auto-update when players join
Players.PlayerAdded:Connect(function(player)
    print(player.Name .. " joined the game")
    updatePlayerCount()
end)

-- Auto-update when players leave
Players.PlayerRemoving:Connect(function(player)
    print(player.Name .. " left the game")
    wait(0.1) -- Small delay to ensure player is fully removed
    updatePlayerCount()
end)

-- Initial update when script starts
updatePlayerCount()
